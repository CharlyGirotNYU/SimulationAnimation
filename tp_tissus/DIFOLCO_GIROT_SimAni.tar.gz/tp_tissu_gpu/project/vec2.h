#ifndef VEC2_H
#define VEC2_H

struct vec2
{
  float x, y;

  vec2 (float x_ = 0, float y_ = 0) : x (x_), y (y_) { }
};

#endif
